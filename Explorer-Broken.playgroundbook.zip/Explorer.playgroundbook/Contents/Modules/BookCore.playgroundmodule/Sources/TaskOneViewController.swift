//
//  TaskOneViewController.swift
//  BookCore
//
//  Created by JiaChen(: on 7/4/21.
//

import UIKit
import PlaygroundSupport
import SceneKit
import SwiftUI

public class TaskOneViewController: UIViewController {

    var taskTitleLabel: UILabel!
    var taskInstructionLabel: UILabel!
    
    public var scnView: SCNView!
    
    public var puzzleStackView: UIStackView!
    
    public var buttonOneView: UIView?
    public var buttonTwoView: UIView?
    public var buttonThreeView: UIView?
    
    var taskOneTitle: UILabel!
    var taskTwoTitle: UILabel!
    var taskThreeTitle: UILabel!
    
    public var breakLockOne: Bool {
        let startIndex = PlaygroundPage.current.text.range(of: "//#-observe-0")?.lowerBound
        let endIndex = PlaygroundPage.current.text.range(of: "//#-end-observe-0")?.upperBound

        let text = String(PlaygroundPage.current.text[startIndex!...endIndex!])
        
        return text.contains(".foregroundColor(.orange)") || text.contains(".foregroundColor(Color.orange)")
    }
    
    public var breakLockTwo: Bool {
        let startIndex = PlaygroundPage.current.text.range(of: "//#-observe-1")?.lowerBound
        let endIndex = PlaygroundPage.current.text.range(of: "//#-end-observe-1")?.upperBound

        let text = String(PlaygroundPage.current.text[startIndex!...endIndex!])
        
        return text.contains(".padding(") && text.contains(".background(Color.orange)")
    }
    
    public var breakLockThree: Bool {
        let startIndex = PlaygroundPage.current.text.range(of: "//#-observe-2")?.lowerBound
        let endIndex = PlaygroundPage.current.text.range(of: "//#-end-observe-2")?.upperBound

        let text = String(PlaygroundPage.current.text[startIndex!...endIndex!])
        
        return text.contains("Button(/*#-editable-code*/\"Amazing!\"/*#-end-editable-code*/) {\n}")
    }
    
    public override func loadView() {
        super.loadView()
        
        let taskTitleLabel = UILabel()
        taskTitleLabel.text = "Unlock the Chest"
        taskTitleLabel.font = .systemFont(ofSize: 32, weight: .bold)
        taskTitleLabel.textAlignment = .center
        taskTitleLabel.textColor = .white
        
        taskTitleLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(taskTitleLabel)
        
        view.addConstraints([NSLayoutConstraint(item: taskTitleLabel,
                                                attribute: .leading,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .leadingMargin,
                                                multiplier: 1,
                                                constant: 16),
                             NSLayoutConstraint(item: taskTitleLabel,
                                                attribute: .trailing,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .trailingMargin,
                                                multiplier: 1,
                                                constant: -16),
                             NSLayoutConstraint(item: taskTitleLabel,
                                                attribute: .top,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .topMargin,
                                                multiplier: 1,
                                                constant: 16)])
        
//        let taskInstructionsLabel = UILabel()
//        taskInstructionsLabel.text = "The chest is locked. To unlock it, edit the buttons on the bottom row such that they are identical to the ones on the top row.\nUse the editor to edit the buttons."
//        taskInstructionsLabel.numberOfLines = 0
//        taskInstructionsLabel.textAlignment = .center
//
//        taskInstructionsLabel.translatesAutoresizingMaskIntoConstraints = false
//        taskInstructionsLabel.textColor = .white
//
//        view.addSubview(taskInstructionsLabel)
//
//        view.addConstraints([NSLayoutConstraint(item: taskInstructionsLabel,
//                                                attribute: .leading,
//                                                relatedBy: .equal,
//                                                toItem: view,
//                                                attribute: .leadingMargin,
//                                                multiplier: 1,
//                                                constant: 16),
//                             NSLayoutConstraint(item: taskInstructionsLabel,
//                                                attribute: .trailing,
//                                                relatedBy: .equal,
//                                                toItem: view,
//                                                attribute: .trailingMargin,
//                                                multiplier: 1,
//                                                constant: -16),
//                             NSLayoutConstraint(item: taskInstructionsLabel,
//                                                attribute: .bottom,
//                                                relatedBy: .equal,
//                                                toItem: view,
//                                                attribute: .bottomMargin,
//                                                multiplier: 1,
//                                                constant: -16)])
        
//        self.taskInstructionLabel = taskInstructionsLabel
        self.taskTitleLabel = taskTitleLabel
        setUpTask()
        setUpPrompt()
    }
    
    func setUpPrompt() {
        let promptView = TKRobotPromptView(with: "The chest is locked. To unlock it, use the editor to edit the buttons on the bottom row such that they are identical to the ones on the top row.\n\nNeed help? Click on me and ask a question.", sender: self)
        
        promptView.translatesAutoresizingMaskIntoConstraints = false
        promptView.clipsToBounds = true
        view.addSubview(promptView)
        
        view.addConstraints([NSLayoutConstraint(item: promptView,
                                                attribute: .leading,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .leadingMargin,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: promptView,
                                                attribute: .trailing,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .trailingMargin,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: promptView,
                                                attribute: .bottom,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .bottomMargin,
                                                multiplier: 1,
                                                constant: -16)])
    }
    
    func setUpTask() {
        let puzzleStackView = UIStackView()
        puzzleStackView.axis = .horizontal
        puzzleStackView.distribution = .fillEqually
        
        puzzleStackView.backgroundColor = UIColor.systemGray4
        
        puzzleStackView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(puzzleStackView)
        
        view.addConstraints([NSLayoutConstraint(item: puzzleStackView,
                                                attribute: .centerX,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .centerXWithinMargins,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: puzzleStackView,
                                                attribute: .centerY,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .centerYWithinMargins,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: puzzleStackView,
                                                attribute: .height,
                                                relatedBy: .equal,
                                                toItem: puzzleStackView,
                                                attribute: .width,
                                                multiplier: 1/2,
                                                constant: 0),
                             NSLayoutConstraint(item: puzzleStackView,
                                                attribute: .width,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .width,
                                                multiplier: 0.9,
                                                constant: 0)])
        
        self.puzzleStackView = puzzleStackView
        
        loadTasks()
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    public override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        PlaygroundPage.current.needsIndefiniteExecution = true
        
        if breakLockOne && breakLockTwo && breakLockThree {
            // Chest unlocked
            taskTitleLabel.text = "Chest Unlocked"
            
            UIView.animate(withDuration: 3, delay: 2, options: .curveEaseInOut) {
                self.puzzleStackView.alpha = 0
            } completion: { (_) in
                PlaygroundPage.current.navigateTo(page: .next)
            }
        }
        
    }
    
    func loadTasks() {
        let taskOne = UIHostingController(rootView: Button("SwiftUI") {}.foregroundColor(.orange)).view!
        let taskTwo = UIHostingController(rootView: Button("is") {}.padding().background(Color.orange)).view!
        let taskThree = UIHostingController(rootView: Button("Amazing!") {}).view!

        let buttonOneView = self.buttonOneView ?? UIHostingController(rootView: Button("SwiftUI") {}).view!
        let buttonTwoView = self.buttonTwoView ?? UIHostingController(rootView: Button("is") {}).view!
        let buttonThreeView = self.buttonThreeView ?? UIHostingController(rootView: Button("Great!") {}).view!
        
        let taskOneTitle = UILabel()
        taskOneTitle.text = "\(breakLockOne ? "🎉" : "🔒")1️⃣"
        taskOneTitle.textAlignment = .center
        
        let taskTwoTitle = UILabel()
        taskTwoTitle.text = "\(breakLockTwo ? "🎉" : "🔒")2️⃣"
        taskTwoTitle.textAlignment = .center
        
        let taskThreeTitle = UILabel()
        taskThreeTitle.text = "\(breakLockThree ? "🎉" : "🔒")3️⃣"
        taskThreeTitle.textAlignment = .center
        
        taskOne.backgroundColor = .clear
        taskOne.translatesAutoresizingMaskIntoConstraints = false
        taskTwo.backgroundColor = .clear
        taskTwo.translatesAutoresizingMaskIntoConstraints = false
        taskThree.backgroundColor = .clear
        taskThree.translatesAutoresizingMaskIntoConstraints = false
        
        buttonOneView.backgroundColor = .clear
        buttonOneView.translatesAutoresizingMaskIntoConstraints = false
        buttonTwoView.backgroundColor = .clear
        buttonTwoView.translatesAutoresizingMaskIntoConstraints = false
        buttonThreeView.backgroundColor = .clear
        buttonThreeView.translatesAutoresizingMaskIntoConstraints = false
        view.addConstraints([NSLayoutConstraint(item: buttonOneView,
                                                attribute: .height,
                                                relatedBy: .equal,
                                                toItem: taskOne,
                                                attribute: .height,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: buttonTwoView,
                                                attribute: .height,
                                                relatedBy: .equal,
                                                toItem: taskTwo,
                                                attribute: .height,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: buttonThreeView,
                                                attribute: .height,
                                                relatedBy: .equal,
                                                toItem: taskThree,
                                                attribute: .height,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: taskOne,
                                                attribute: .height,
                                                relatedBy: .equal,
                                                toItem: taskThree,
                                                attribute: .height,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: taskOne,
                                                attribute: .height,
                                                relatedBy: .equal,
                                                toItem: taskTwo,
                                                attribute: .height,
                                                multiplier: 1,
                                                constant: 0)])
        
        let taskOneStackView = UIStackView(arrangedSubviews: [taskOneTitle, taskOne, buttonOneView])
        taskOneStackView.axis = .vertical
        taskOneStackView.distribution = .fillProportionally
        let taskTwoStackView = UIStackView(arrangedSubviews: [taskTwoTitle, taskTwo, buttonTwoView])
        taskTwoStackView.axis = .vertical
        taskTwoStackView.distribution = .fillProportionally
        let taskThreeStackView = UIStackView(arrangedSubviews: [taskThreeTitle, taskThree, buttonThreeView])
        taskThreeStackView.axis = .vertical
        taskThreeStackView.distribution = .fillProportionally
        
        puzzleStackView.addArrangedSubview(taskOneStackView)
        puzzleStackView.addArrangedSubview(taskTwoStackView)
        puzzleStackView.addArrangedSubview(taskThreeStackView)
        
        self.taskOneTitle = taskOneTitle
        self.taskTwoTitle = taskTwoTitle
        self.taskThreeTitle = taskThreeTitle
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
