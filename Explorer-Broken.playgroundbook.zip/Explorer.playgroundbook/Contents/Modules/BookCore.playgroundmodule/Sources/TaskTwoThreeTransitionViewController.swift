//
//  TaskTwoThreeTransitionViewController.swift
//  BookCore
//
//  Created by JiaChen(: on 13/4/21.
//

import UIKit
import PlaygroundSupport
import SceneKit

public class TaskTwoThreeTransitionViewController: UIViewController, SCNSceneRendererDelegate {
    
    let collisionMap: [[Bool]] = [
        [true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true],
        [true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true],
        [true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true],
        [true, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, true],
        [true, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, true],
        [true, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, true],
        [true, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, true],
        [true, false, false, false, false, false, true, true, false, false, false, false, false, false, false, false, false, false, false, true],
        [true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true],
        [true, false, false, false, false, false, false, false, false, false, false, false, true, true, true, true, false, false, false, true],
        [true, false, false, false, false, false, false, false, false, false, false, false, true, true, true, true, false, false, false, true],
        [true, false, false, false, false, false, false, false, false, false, false, false, true, true, true, true, false, false, false, true],
        [true, false, false, false, false, false, false, true, false, false, false, false, true, true, true, true, false, false, false, true],
        [true, false, false, false, false, false, false, true, false, false, false, false, true, true, true, true, false, false, false, true],
        [true, false, false, false, false, false, false, true, false, false, false, false, true, true, true, true, false, false, false, true],
        [true, false, false, false, false, false, false, true, false, false, false, false, true, true, true, true, false, false, false, true],
        [true, true, true, true, true, true, true, true, false, false, false, false, false, false, false, false, false, false, false, true],
        [true, true, true, true, true, true, true, true, false, false, false, false, false, false, false, false, false, false, false, true],
        [true, true, true, true, true, true, true, true, false, false, false, false, false, false, false, false, false, false, false, true],
        [true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, false, false, true, true]]
    
    var scnScene: SCNScene!
    
    var scnView: SCNView!
    
    var cameraNode: SCNNode!
    
    var moveButton: UIButton!
    
    var turnLeadingButton: UIButton!
    
    var promptView: TKRobotPromptView!
    
    public override func loadView() {
        super.loadView()
        
        setUpScene()
        setUpMoveButton()
        setUpTurnLeadingButton()
        setUpPrompt()
    }
    
    func setUpScene() {
        
        scnScene = SCNScene(named: "PlayerMap.scn")!
        
        let scnView = SCNView()
        
        scnView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scnView)
        
        let panGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(pan(_:)))
        
        scnView.addGestureRecognizer(panGestureRecognizer)
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(tapped(_:)))
        scnView.addGestureRecognizer(tapGestureRecognizer)
        
        view.addConstraints([NSLayoutConstraint(item: scnView,
                                                attribute: .leading,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .leading,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: scnView,
                                                attribute: .trailing,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .trailing,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: scnView,
                                                attribute: .topMargin,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .topMargin,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: scnView,
                                                attribute: .bottomMargin,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .bottomMargin,
                                                multiplier: 1,
                                                constant: 0)])
        
        self.scnView = scnView
    }
    
    func setUpMoveButton() {
        let moveButton = UIButton()
        
        moveButton.setImage(UIImage(systemName: "arrowtriangle.up.fill"), for: .normal)
        moveButton.translatesAutoresizingMaskIntoConstraints = false
        
        moveButton.addTarget(self, action: #selector(moveForward), for: .touchUpInside)
        
        moveButton.backgroundColor = .systemGray4
        moveButton.layer.cornerRadius = 32
        
        view.addSubview(moveButton)
        
        view.addConstraints([NSLayoutConstraint(item: moveButton,
                                                attribute: .centerX,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .centerXWithinMargins,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: moveButton,
                                                attribute: .bottom,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .bottomMargin,
                                                multiplier: 1,
                                                constant: -72),
                             NSLayoutConstraint(item: moveButton,
                                                attribute: .width,
                                                relatedBy: .equal,
                                                toItem: moveButton,
                                                attribute: .height,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: moveButton,
                                                attribute: .width,
                                                relatedBy: .equal,
                                                toItem: nil,
                                                attribute: .notAnAttribute,
                                                multiplier: 1,
                                                constant: 64)])
        
        self.moveButton = moveButton
    }
    
    func setUpTurnLeadingButton() {
        let turnLeadingButton = UIButton()
        let turnTrailingButton = UIButton()
        
        let stackView = UIStackView()
        
        turnLeadingButton.setImage(UIImage(systemName: "arrowtriangle.left.fill"), for: .normal)
        turnLeadingButton.translatesAutoresizingMaskIntoConstraints = false
        turnLeadingButton.backgroundColor = .systemGray4
        turnLeadingButton.layer.cornerRadius = 32
        turnLeadingButton.addTarget(self, action: #selector(turnLeading), for: .touchUpInside)
        
        turnTrailingButton.setImage(UIImage(systemName: "arrowtriangle.right.fill"), for: .normal)
        turnTrailingButton.translatesAutoresizingMaskIntoConstraints = false
        turnTrailingButton.backgroundColor = .systemGray4
        turnTrailingButton.layer.cornerRadius = 32
        turnTrailingButton.addTarget(self, action: #selector(turnTrailing), for: .touchUpInside)
        
        //        turnLeadingButton.addTarget(self, action: #selector(moveForward), for: .touchUpInside)
        
        stackView.addArrangedSubview(turnLeadingButton)
        stackView.addArrangedSubview(turnTrailingButton)
        
        stackView.distribution = .fillEqually
        stackView.axis = .horizontal
        
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.spacing = 16
        
        view.addSubview(stackView)
        
        view.addConstraints([NSLayoutConstraint(item: stackView,
                                                attribute: .centerX,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .centerXWithinMargins,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: stackView,
                                                attribute: .width,
                                                relatedBy: .equal,
                                                toItem: stackView,
                                                attribute: .height,
                                                multiplier: 2,
                                                constant: 16),
                             NSLayoutConstraint(item: stackView,
                                                attribute: .bottom,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .bottomMargin,
                                                multiplier: 1,
                                                constant: -8),
                             NSLayoutConstraint(item: stackView,
                                                attribute: .height,
                                                relatedBy: .equal,
                                                toItem: nil,
                                                attribute: .notAnAttribute,
                                                multiplier: 1,
                                                constant: 64)])
    }
    
    @objc func pan(_ sender: UIPanGestureRecognizer) {
        let rotateAction = SCNAction.rotateBy(x: (sender.translation(in: sender.view!).y / sender.view!.bounds.height) * .pi,
                                              y: (sender.translation(in: sender.view!).x / sender.view!.bounds.width) * .pi,
                                              z: 0, duration: 0)
        
        sender.setTranslation(.zero, in: sender.view!)
        
        cameraNode.runAction(rotateAction)
    }
    
    @objc func tapped(_ sender: UITapGestureRecognizer) {
        let location = sender.location(in: scnView)
        let hits = self.scnView.hitTest(location, options: nil)
        
        if hits.filter({ $0.node.name == "card" }).first != nil {
            PlaygroundPage.current.navigateTo(page: .next)
        }
    }
    
    @objc func turnLeading() {
        let rotateAction = SCNAction.rotateBy(x: 0,
                                              y: .pi / 180 * 15,
                                              z: 0, duration: 0.2)
        
        cameraNode.runAction(rotateAction)
    }
    
    @objc func turnTrailing() {
        let rotateAction = SCNAction.rotateBy(x: 0,
                                              y: -.pi / 180 * 15,
                                              z: 0, duration: 0.2)
        
        cameraNode.runAction(rotateAction)
    }
    
    @objc func moveForward() {
        
        var direction = Int(round((cameraNode.eulerAngles.y / .pi * 180) / 90)) % 4
        
        var possibleMovements = [SCNVector3(0, 0, -0.5), // 0º   (Forward)
                                 SCNVector3(-0.5, 0, 0), // 90º  (Left/Right)
                                 SCNVector3(0, 0, 0.5),  // 180º (Down)
                                 SCNVector3(0.5, 0, 0)]  // 270º (Left/Right)
        
        if direction < 0 {
            direction *= -1
            possibleMovements = [SCNVector3(0, 0, -0.5), // 0º   (Forward)
                                 SCNVector3(0.5, 0, 0), // 90º  (Left/Right)
                                 SCNVector3(0, 0, 0.5),  // 180º (Down)
                                 SCNVector3(-0.5, 0, 0)]  // 270º (Left/Right)
            
        }
        
        if direction > 3 { return }
        
        let movement = possibleMovements[direction]
        
        let moveAction = SCNAction.move(by: movement, duration: 0.2)
        
        moveAction.timingMode = .easeInEaseOut
        
        let newZ = Int(round((cameraNode.position.z + 4.75 + movement.z) / 0.5))
        let newX = Int(round((cameraNode.position.x + 4.75 + movement.x) / 0.5))
        
        if 0...19 ~= newZ && 0...19 ~= newX {
            let isWall = collisionMap.reversed()[newZ].reversed()[newX]
            
            if !isWall {
                cameraNode.runAction(moveAction)
            }
        }
    }
    
    func setUpPrompt() {
        let promptView = TKRobotPromptView(with: "Okay, according to the document, we just need to find the card scanner. After that, we just click on it and we should be out of here!", sender: self)
        
        promptView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(promptView)
        
        view.addConstraints([NSLayoutConstraint(item: promptView,
                                                attribute: .leading,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .leadingMargin,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: promptView,
                                                attribute: .trailing,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .trailingMargin,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: promptView,
                                                attribute: .top,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .topMargin,
                                                multiplier: 1,
                                                constant: 16)])
        
        self.promptView = promptView
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        setupCamera()
        
        scnView.delegate = self
    }
    
    func setupCamera() {
        scnView.autoenablesDefaultLighting = false
        cameraNode = SCNNode()
        let camera = SCNCamera()
        cameraNode.position = SCNVector3(x: 2.75, y: 1.6, z: -0.75)
        
        scnView.defaultCameraController.interactionMode = .fly
        
        camera.zNear = 0
        camera.focalLength = 20
        
        cameraNode.camera = camera
        
        scnScene.rootNode.addChildNode(cameraNode)
        
        scnView.scene = scnScene
    }
}
