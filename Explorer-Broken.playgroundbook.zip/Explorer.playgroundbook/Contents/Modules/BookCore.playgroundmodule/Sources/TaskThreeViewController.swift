//
//  TaskThreeViewController.swift
//  BookCore
//
//  Created by JiaChen(: on 12/4/21.
//

import UIKit

public class TaskThreeViewController: UIViewController {
    //w: 0.144, h: 0.229
    
    var taskTitleLabel: UILabel!
    
    var cardScannerView: UIView!
    var cardScannerIndicator: UIView!
    
    var promptView: TKRobotPromptView!
    
    let confettiView = SwiftConfettiView()
    var blurView = UIVisualEffectView()
    
    public var isCorrect = false {
        didSet {
            cardScannerIndicator.backgroundColor = isCorrect ? .systemGreen : .systemRed
            
            if isCorrect {
                // Launch confetti
                view.bringSubviewToFront(blurView)
                view.bringSubviewToFront(promptView)
                view.bringSubviewToFront(taskTitleLabel)
                view.bringSubviewToFront(confettiView)
                
                blurView.isHidden = false
                
                Timer.scheduledTimer(withTimeInterval: 0.5, repeats: false) { (_) in
                    self.confettiView.startConfetti()
                }
                
                promptView.promptText = "You did it!\nYou managed to escape from the dungeon!"
                taskTitleLabel.text = "🎉 You Escaped!"
            }
        }
    }
    
    public override func loadView() {
        super.loadView()
        
        let taskTitleLabel = UILabel()
        taskTitleLabel.text = "Bypass the Door"
        taskTitleLabel.font = .systemFont(ofSize: 32, weight: .bold)
        taskTitleLabel.textAlignment = .center
        taskTitleLabel.textColor = .white
        
        taskTitleLabel.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(taskTitleLabel)
        
        view.addConstraints([NSLayoutConstraint(item: taskTitleLabel,
                                                attribute: .leading,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .leadingMargin,
                                                multiplier: 1,
                                                constant: 16),
                             NSLayoutConstraint(item: taskTitleLabel,
                                                attribute: .trailing,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .trailingMargin,
                                                multiplier: 1,
                                                constant: -16),
                             NSLayoutConstraint(item: taskTitleLabel,
                                                attribute: .top,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .topMargin,
                                                multiplier: 1,
                                                constant: 16)])
        
        setUpPrompt()
        
        let cardScannerView = UIView()
        cardScannerView.backgroundColor = .init(white: 0.15, alpha: 1)
        cardScannerView.layer.cornerRadius = 18
        cardScannerView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(cardScannerView)
        
        view.addConstraints([NSLayoutConstraint(item: cardScannerView,
                                                attribute: .centerX,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .centerX,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: cardScannerView,
                                                attribute: .top,
                                                relatedBy: .equal,
                                                toItem: taskTitleLabel,
                                                attribute: .bottom,
                                                multiplier: 1,
                                                constant: 16),
                             NSLayoutConstraint(item: cardScannerView,
                                                attribute: .width,
                                                relatedBy: .equal,
                                                toItem: cardScannerView,
                                                attribute: .height,
                                                multiplier: 0.144 / 0.229,
                                                constant: 0),
                             NSLayoutConstraint(item: cardScannerView,
                                                attribute: .bottom,
                                                relatedBy: .equal,
                                                toItem: promptView,
                                                attribute: .top,
                                                multiplier: 1,
                                                constant: -16)])
        
        let cardScannerIndicator = UIView()
        cardScannerIndicator.backgroundColor = .systemRed
        cardScannerIndicator.translatesAutoresizingMaskIntoConstraints = false
        
        cardScannerView.addSubview(cardScannerIndicator)

        view.addConstraints([NSLayoutConstraint(item: cardScannerIndicator,
                                                attribute: .centerX,
                                                relatedBy: .equal,
                                                toItem: cardScannerView,
                                                attribute: .centerX,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: cardScannerIndicator,
                                                attribute: .top,
                                                relatedBy: .equal,
                                                toItem: cardScannerView,
                                                attribute: .top,
                                                multiplier: 1,
                                                constant: 32),
                             NSLayoutConstraint(item: cardScannerIndicator,
                                                attribute: .width,
                                                relatedBy: .equal,
                                                toItem: cardScannerView,
                                                attribute: .width,
                                                multiplier: 0.4,
                                                constant: 0),
                             NSLayoutConstraint(item: cardScannerIndicator,
                                                attribute: .height,
                                                relatedBy: .equal,
                                                toItem: cardScannerIndicator,
                                                attribute: .width,
                                                multiplier: 0.04,
                                                constant: 0)])
        
        self.cardScannerIndicator = cardScannerIndicator
        self.cardScannerView = cardScannerView
        self.taskTitleLabel = taskTitleLabel
    }
    
    func setUpPrompt() {
        
        blurView.effect = UIBlurEffect(style: .regular)
        
        blurView.translatesAutoresizingMaskIntoConstraints = false
        blurView.isHidden = true
        view.addSubview(blurView)
        
        view.addConstraints([NSLayoutConstraint(item: blurView,
                                                attribute: .leading,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .leading,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: blurView,
                                                attribute: .trailing,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .trailing,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: blurView,
                                                attribute: .top,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .top,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: blurView,
                                                attribute: .bottom,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .bottom,
                                                multiplier: 1,
                                                constant: 0)])
        
        let promptView = TKRobotPromptView(with: isCorrect ? "You did it!\nYou managed to escape from the dungeon!" : "You've found the source code behind the door! Now we just need to make minor edits to let ourselves through.\n\nNeed help? Click on me and ask a question.", sender: self)
        
        promptView.translatesAutoresizingMaskIntoConstraints = false
        promptView.clipsToBounds = true
        view.addSubview(promptView)
        
        view.addConstraints([NSLayoutConstraint(item: promptView,
                                                attribute: .leading,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .leadingMargin,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: promptView,
                                                attribute: .trailing,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .trailingMargin,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: promptView,
                                                attribute: .bottom,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .bottomMargin,
                                                multiplier: 1,
                                                constant: -16)])
        
        self.promptView = promptView
        
        confettiView.type = .image(UIImage(named: "confetti") ?? UIImage(named: "confetti.png") ?? UIImage(systemName: "triangle.fill")!)
        confettiView.colors = [UIColor(red:0.95, green:0.40, blue:0.27, alpha:1.0),
                               UIColor(red:1.00, green:0.78, blue:0.36, alpha:1.0),
                               UIColor(red:0.48, green:0.78, blue:0.64, alpha:1.0),
                               UIColor(red:0.30, green:0.76, blue:0.85, alpha:1.0),
                               UIColor(red:0.58, green:0.39, blue:0.55, alpha:1.0)]
        confettiView.intensity = 1
        confettiView.isUserInteractionEnabled = false
        confettiView.alpha = 0.5
        confettiView.layer.zPosition = 100
        view.addSubview(confettiView)
        confettiView.translatesAutoresizingMaskIntoConstraints = false
        view.addConstraints([NSLayoutConstraint(item: confettiView,
                                                attribute: .bottom,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .bottom,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: confettiView,
                                                attribute: .trailing,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .trailing,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: confettiView,
                                                attribute: .top,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .top,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: confettiView,
                                                attribute: .leading,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .leading,
                                                multiplier: 1,
                                                constant: 0)])
        
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
