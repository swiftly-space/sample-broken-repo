//
//  TKRobotPromptView.swift
//  BookCore
//
//  Created by JiaChen(: on 14/4/21.
//

import UIKit

public class TKRobotPromptView: UIView {
    
    var sourceViewController: UIViewController!
    
    public var promptText: String? {
        didSet {
            promptLabel.text = promptText
        }
    }
    
    var promptLabel: UILabel!
    
    public init(with text: String? = nil, sender: UIViewController) {
        super.init(frame: .zero)
        
        self.sourceViewController = sender
        
        setUp(with: text)
        
    }
    
    public required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    func setUp(with text: String? = nil) {
        
        let promptView = UIView()
        let profilePicture = UIImageView()
        let promptLabel = UILabel()
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(didTap))
        promptView.isUserInteractionEnabled = true
        promptView.addGestureRecognizer(tapGestureRecognizer)
        profilePicture.isUserInteractionEnabled = true
        profilePicture.addGestureRecognizer(tapGestureRecognizer)
        
        promptLabel.textColor = .label
        promptLabel.numberOfLines = 0
        promptLabel.text = text
        promptLabel.translatesAutoresizingMaskIntoConstraints = false
        promptView.translatesAutoresizingMaskIntoConstraints = false
        profilePicture.translatesAutoresizingMaskIntoConstraints = false
        
        promptView.layer.cornerRadius = 10
        promptView.clipsToBounds = true
        promptView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
        profilePicture.image = UIImage(named: "tk-profile")
        profilePicture.layer.cornerRadius = 35
        profilePicture.clipsToBounds = true
        
        promptView.backgroundColor = UIColor(named: "graynotreally")
        
        addSubview(promptView)
        addSubview(profilePicture)
        promptView.addSubview(promptLabel)
        
        addConstraints([NSLayoutConstraint(item: promptView,
                                           attribute: .leading,
                                           relatedBy: .greaterThanOrEqual,
                                           toItem: self,
                                           attribute: .leading,
                                           multiplier: 1,
                                           constant: 16),
                        NSLayoutConstraint(item: promptView,
                                           attribute: .top,
                                           relatedBy: .equal,
                                           toItem: self,
                                           attribute: .top,
                                           multiplier: 1,
                                           constant: 0),
                        NSLayoutConstraint(item: promptLabel,
                                           attribute: .top,
                                           relatedBy: .equal,
                                           toItem: promptView,
                                           attribute: .top,
                                           multiplier: 1,
                                           constant: 12),
                        NSLayoutConstraint(item: promptLabel,
                                           attribute: .leading,
                                           relatedBy: .equal,
                                           toItem: promptView,
                                           attribute: .leading,
                                           multiplier: 1,
                                           constant: 12),
                        NSLayoutConstraint(item: promptLabel,
                                           attribute: .trailing,
                                           relatedBy: .equal,
                                           toItem: promptView,
                                           attribute: .trailing,
                                           multiplier: 1,
                                           constant: -12),
                        NSLayoutConstraint(item: promptLabel,
                                           attribute: .bottom,
                                           relatedBy: .equal,
                                           toItem: promptView,
                                           attribute: .bottom,
                                           multiplier: 1,
                                           constant: -12),
                        NSLayoutConstraint(item: promptView,
                                           attribute: .trailing,
                                           relatedBy: .equal,
                                           toItem: profilePicture,
                                           attribute: .leading,
                                           multiplier: 1,
                                           constant: -8),
                        NSLayoutConstraint(item: profilePicture,
                                           attribute: .width,
                                           relatedBy: .equal,
                                           toItem: nil,
                                           attribute: .notAnAttribute,
                                           multiplier: 1,
                                           constant: 70),
                        NSLayoutConstraint(item: profilePicture,
                                           attribute: .height,
                                           relatedBy: .equal,
                                           toItem: nil,
                                           attribute: .notAnAttribute,
                                           multiplier: 1,
                                           constant: 70),
                        NSLayoutConstraint(item: profilePicture,
                                           attribute: .top,
                                           relatedBy: .equal,
                                           toItem: self,
                                           attribute: .top,
                                           multiplier: 1,
                                           constant: 0),
                        NSLayoutConstraint(item: profilePicture,
                                           attribute: .trailing,
                                           relatedBy: .equal,
                                           toItem: self,
                                           attribute: .trailing,
                                           multiplier: 1,
                                           constant: -16),
                        NSLayoutConstraint(item: promptView,
                                           attribute: .bottom,
                                           relatedBy: .equal,
                                           toItem: self,
                                           attribute: .bottom,
                                           multiplier: 1,
                                           constant: 0)])
        
        self.promptLabel = promptLabel
    }
    
    @objc func didTap() {
        let nvc = UINavigationController(rootViewController: ChatbotViewController())
        sourceViewController.present(nvc, animated: true)
    }
}
