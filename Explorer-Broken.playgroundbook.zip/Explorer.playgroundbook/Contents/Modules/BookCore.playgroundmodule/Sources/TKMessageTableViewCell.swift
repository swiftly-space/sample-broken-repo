//
//  MessageTableViewCell.swift
//  BookCore
//
//  Created by JiaChen(: on 16/4/21.
//

import UIKit

class TKMessageTableViewCell: UITableViewCell, MessageManager {
    
    var message: Message! {
        didSet {
            // anything within `this` will be code spaced
            let regularExpression = "`.+`"
            let attributedString = NSMutableAttributedString(string: message.message,
                                                      attributes: [.font : UIFont.systemFont(ofSize: UIFont.labelFontSize)])
            
            let regex = try! NSRegularExpression(pattern: regularExpression, options: [])
            let matches = regex.matches(in: message.message, options: [], range: NSRange(location: 0, length: message.message.count)).map { $0.range }
            
            for match in matches {
                attributedString.addAttributes([.font : UIFont.monospacedSystemFont(ofSize: UIFont.labelFontSize, weight: .regular), .foregroundColor : UIColor(named: "Fancy Yellow")!], range: match)
                
                let firstBacktick = NSRange(location: match.lowerBound, length: 1)
                let lastBacktick = NSRange(location: match.upperBound - 1, length: 1)
                
                attributedString.addAttribute(.foregroundColor, value: UIColor.clear, range: firstBacktick)
                attributedString.addAttribute(.foregroundColor, value: UIColor.clear, range: lastBacktick)
            }
            
            messageLabel.attributedText = attributedString
        }
    }
    
    var messageLabel = UILabel()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        let promptView = UIView()
        
        promptView.backgroundColor = UIColor(named: "graynotreally")
        promptView.layer.cornerRadius = 10
        promptView.clipsToBounds = true
        promptView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMaxYCorner, .layerMaxXMinYCorner]
        
        promptView.translatesAutoresizingMaskIntoConstraints = false
        
        contentView.addSubview(promptView)
        
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
        messageLabel.numberOfLines = 0
        promptView.addSubview(messageLabel)
        
        contentView.addConstraints([NSLayoutConstraint(item: promptView,
                                                       attribute: .leading,
                                                       relatedBy: .equal,
                                                       toItem: contentView,
                                                       attribute: .leading,
                                                       multiplier: 1,
                                                       constant: 8),
                                    NSLayoutConstraint(item: promptView,
                                                       attribute: .top,
                                                       relatedBy: .equal,
                                                       toItem: contentView,
                                                       attribute: .top,
                                                       multiplier: 1,
                                                       constant: 8),
                                    NSLayoutConstraint(item: promptView,
                                                       attribute: .bottom,
                                                       relatedBy: .equal,
                                                       toItem: contentView,
                                                       attribute: .bottom,
                                                       multiplier: 1,
                                                       constant: -8),
                                    NSLayoutConstraint(item: promptView,
                                                       attribute: .width,
                                                       relatedBy: .lessThanOrEqual,
                                                       toItem: contentView,
                                                       attribute: .width,
                                                       multiplier: 2/3,
                                                       constant: 0),
                                    NSLayoutConstraint(item: messageLabel,
                                                       attribute: .top,
                                                       relatedBy: .equal,
                                                       toItem: promptView,
                                                       attribute: .top,
                                                       multiplier: 1,
                                                       constant: 12),
                                    NSLayoutConstraint(item: messageLabel,
                                                       attribute: .leading,
                                                       relatedBy: .equal,
                                                       toItem: promptView,
                                                       attribute: .leading,
                                                       multiplier: 1,
                                                       constant: 12),
                                    NSLayoutConstraint(item: messageLabel,
                                                       attribute: .trailing,
                                                       relatedBy: .equal,
                                                       toItem: promptView,
                                                       attribute: .trailing,
                                                       multiplier: 1,
                                                       constant: -12),
                                    NSLayoutConstraint(item: messageLabel,
                                                       attribute: .bottom,
                                                       relatedBy: .equal,
                                                       toItem: promptView,
                                                       attribute: .bottom,
                                                       multiplier: 1,
                                                       constant: -12)])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
