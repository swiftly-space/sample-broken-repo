//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import SwiftUI
import UIKit
import PlaygroundSupport
import BookCore
//struct CardScanner: View {
//    var body: some View {
//        Rectangle().background(Color.clear)
//    }
//}
//#-end-hidden-code
//: ````
//:   __,                    ,   , ____
//:  (           o  /) _/_  /   /   /
//:   `.  , , , ,  //  /   /   /;  /
//: (___)(_(_/_(_ //_ (__ (___/ (_‘__
//:              /)
//:             (/
//: ````
//: # Task 3: Open the Door
//: 🎉 You've found the source code for door 1!
//:
//: ## DoorOne.swift
//: Due to a vulnerability, the `DoorOne.swift` file got exposed accidentally and you are now able to edit the contents of the file and bypass the door.
//:
//: The contents of the file is presented below.
var isAuthorized = checkAuthorization()

struct DoorOne: View {
    
    @State var isUnlocked = false
    
    var body: some View {
        HStack {
//#-hidden-code
            Rectangle()
        }
    }
}
var isUnlocked = false
//#-end-hidden-code
            CardScanner {
                // What happens when a card is scanned
                isUnlocked = /*#-editable-code*/isAuthorized/*#-end-editable-code*/
//#-hidden-code
                return isUnlocked
//#-end-hidden-code
            }
//#-hidden-code
struct DoorOne_Preview: View {
    
    @State var isUnlocked = false
    
    var body: some View {
//#-end-hidden-code
            Door(isUnlocked: $isUnlocked)
        }
    }
//#-hidden-code
_ = {
//#-end-hidden-code
}
//#-hidden-code
func checkAuthorization() -> Bool {
    return false
}

func CardScanner(_ onScan: (() -> Bool)) {
    onScan()
}

func Door(isUnlocked: Binding<Bool>) -> some View {
    return Rectangle()
}

func initialize() {
    let liveViewController = TaskThreeViewController()
    PlaygroundPage.current.liveView = liveViewController
    liveViewController.isCorrect = isUnlocked
}

initialize()
//#-end-hidden-code
