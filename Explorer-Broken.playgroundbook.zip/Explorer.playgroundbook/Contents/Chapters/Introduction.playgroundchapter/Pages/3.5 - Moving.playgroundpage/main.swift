//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import SwiftUI
import PlaygroundSupport
import BookCore
//#-end-hidden-code
//: ````
//:   __,                    ,   , ____
//:  (           o  /) _/_  /   /   /
//:   `.  , , , ,  //  /   /   /;  /
//: (___)(_(_/_(_ //_ (__ (___/ (_‘__
//:              /)
//:             (/
//: ````
//: # Exploring Beyond
//: ## Report
//: You found this report in the chest. Seems like there's something wrong with Door 1.
//: ![3.5-01.png](3.5-01.png)


