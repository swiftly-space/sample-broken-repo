//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
//: ````
//:   __,                    ,   , ____
//:  (           o  /) _/_  /   /   /
//:   `.  , , , ,  //  /   /   /;  /
//: (___)(_(_/_(_ //_ (__ (___/ (_‘__
//:              /)
//:             (/
//: ````
//: > This Playground is best experienced with dark mode enabled on macOS.
//:
//: # What's This?
//: This Playground was inspired by my experience developing curriculum for SwiftUI and UIKit for various iOS development lessons. The Playground is intended to teach learners the basics of SwiftUI through an interactive 3D escape room in a fun and engaging way. The Playground is broken down into 5 parts with 3 tasks to complete.
//:
//: You can look through the tutorial on the right to better understand the SwiftUI functions you'll need to complete this challenge. Once you're done, press the `x` button and you can chat with T Krobot.
//: > Avoid navigating using the navigator on the left side and use the Live View instead/
//: >
//: > This helps prevent spoilers.
